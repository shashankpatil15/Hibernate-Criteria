# Hibernate-Criteria
Simple demonstration of using Criteria using Hibernate
